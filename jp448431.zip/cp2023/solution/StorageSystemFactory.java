/*
 * University of Warsaw
 * Concurrent Programming Course 2023/2024
 * Java Assignment
 *
 * Author: Konrad Iwanicki (iwanicki@mimuw.edu.pl)
 */
package cp2023.solution;

import java.util.Map;

import cp2023.base.ComponentId;
import cp2023.base.DeviceId;
import cp2023.base.StorageSystem;


public final class StorageSystemFactory {

    public static StorageSystem newSystem(
            Map<DeviceId, Integer> deviceTotalSlots,
            Map<ComponentId, DeviceId> componentPlacement) {

            System newsys = new System();
            if (deviceTotalSlots.size() == 0){  // Jeśli brak jakichkolwiek urządzeń w systemie.
                throw new IllegalArgumentException("There are no devices in the system.");
            }
            for (Map.Entry<DeviceId, Integer> entry : deviceTotalSlots.entrySet()){
                if (entry.getKey() == null){  // Urządzenie jest null.
                    throw new IllegalArgumentException("Device is null.");
                }
                if (entry.getValue() == null || entry.getValue() <= 0)  // Sprawdza, czy urządzenia mają więcej, niż zero miejsca bazowo.
                {
                    throw new IllegalArgumentException("Device " + entry.getKey() + " has no space while initiating.");
                }
                newsys.putDev(new Device(entry.getKey(), entry.getValue()));  // Wstawia urządzenie o poprawnym rozmiarze.
            }
            for (Map.Entry<ComponentId, DeviceId>  entry : componentPlacement.entrySet()){
                if (entry.getKey() == null){  // Komponent jest null.
                    throw new IllegalArgumentException("Component is null.");
                }
                if (entry.getValue() == null){  // Device jest null.
                    throw new IllegalArgumentException("Component " + entry.getKey() + " is being assigned to a device which is null.");
                }
                newsys.putComp(entry.getKey(), entry.getValue());  // Wstawia komponenty do systemu.
            }
            return newsys;  // Przekazuje gotowy system.
    }

}
