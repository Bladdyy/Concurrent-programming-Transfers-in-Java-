package cp2023.solution;


import cp2023.base.ComponentId;
import cp2023.base.ComponentTransfer;
import cp2023.base.DeviceId;

import java.util.LinkedList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Semaphore;

public class Device {
    private DeviceId deviceId;  // Id urządzenia.
    private int sizeLeft;  // Wolne miejsce na urządzeniu.

    // Lista transferów, czekających na miejsce na tym urządzeniu.
    private final LinkedList<ComponentTransfer> waiting = new LinkedList<>();

    // Semaphore'y transferów przenoszących się na to urządzenie.
    private final Map<ComponentId, Semaphore> semaphores = new ConcurrentHashMap<>();

    // Semaphore'y nałożone przez ostatnie transfery łańcuchów, które nie zakończyły 'prepare'.
    private final LinkedList<Semaphore> prepares = new LinkedList<>();


    public Device(DeviceId deviceId, int size){
        this.deviceId = deviceId;
        sizeLeft = size;
    }

    // Dodaje semaphore od transferu robiącego 'prepare'.
    public void addPrep(Semaphore sem){
        prepares.add(sem);
    }

    // Sprawdza, czy wszystkie miejsca wolne są jeszcze zajmowane przez transfery robiące 'prepare'.
    public boolean checkPrep(){
        return prepares.size() == sizeLeft;
    }

    // Sprawdza, czy transfer czeka. Jeśli tak, to usuwa jego semaphore.
    public boolean checkAndRemove(Semaphore sem){

        boolean found = false;
        int index = 0;
        while (index < prepares.size() && !found){  // Póki nie znajdzie semaphore'a lub nie sprawdzi wszystkich.
            if (prepares.get(index).equals(sem)){  // Semaphore został znaleziony.
                found = true;
                prepares.remove(index);
            }
            index++;
        }
        return found;
    }

    // Daje semaphore transferu, który najdłużej robi 'prepare', poczym go usuwa.
    public Semaphore getPrep(){
        Semaphore temp = prepares.getFirst();
        prepares.removeFirst();
        return temp;
    }
    // Zapisuje semaphore dla danego transferu.
    public void addSem(ComponentTransfer transfer, Semaphore semaphore){
        semaphores.put(transfer.getComponentId(), semaphore);
    }

    // Daje semaphore związany z danym transferem.
    public Semaphore getSem(ComponentTransfer transfer){
        return semaphores.get(transfer.getComponentId());
    }

    // Usuwa semaphore związany z danym transferem.
    public void removeSem(ComponentTransfer transfer){
        semaphores.remove(transfer.getComponentId());
    }

    // Rezerwuje miejsce dla nowego komponentu.
    public void addComponent()
    {
        sizeLeft--;
    }

    // Zwalnia miejsce po komponencie.
    public void removeComponent() { sizeLeft++; }

    // Dodaje nowy transfer, który czeka na miejsce na urządzeniu.
    public void waitDev(ComponentTransfer transfer){
        waiting.add(transfer);
    }

    // Usuwa transfer z listy czekających.
    public void transferDev(ComponentTransfer transfer){
        waiting.remove(transfer);
    }
    public LinkedList<ComponentTransfer> getWaiting(){
        return waiting;
    }
    public DeviceId getID()
    {
        return deviceId;
    }
    public int getSizeLeft()
    {
        return sizeLeft;
    }

}
