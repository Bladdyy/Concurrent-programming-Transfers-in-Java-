package cp2023.solution;

import cp2023.base.ComponentId;
import cp2023.base.ComponentTransfer;
import cp2023.base.DeviceId;
import cp2023.base.StorageSystem;
import cp2023.exceptions.*;

import java.util.*;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Semaphore;

public class System implements StorageSystem {
    // Trzyma urządzenia o danym ID.
    private final Map<DeviceId, Device> deviceInfo = new HashMap<>();

    // Trzyma informację o ID urządzenia, na którym jest komponent o danym ID.
    private final Map<ComponentId, DeviceId> compLoc = Collections.synchronizedMap(new HashMap<>());

    // Trzyma semaphore'y dla transferów, które czekają na miejsce na urządzeniu docelowym.
    private final Map<ComponentTransfer, Semaphore> waiting = new ConcurrentHashMap<>();
    // Trzyma semaphore'y dla transferów, które czekają na prepare poprzednika.
    private final Map<ComponentTransfer, Semaphore> performs = new ConcurrentHashMap<>();

    // Trzyma ID komponentów, które są w trakcie transferu.
    private final Set<ComponentId> beingTransfered = Collections.synchronizedSet(new HashSet<>());

    // Semaphore wpuszczający jeden tranfer naraz.
    private final Semaphore transferMutex = new Semaphore(1);

    // Semaphore kontrolujący 'prepare' niezależnych od siebie transferów.
    private final Semaphore prepMutex = new Semaphore(1);

    // Trzyma ostatnie transfery w grupach możliwych do wykonania transferów.
    private final Set<ComponentTransfer> tails =  Collections.synchronizedSet(new HashSet<>());


    // Obsługuje nowo przybyłe transfery.
    public void execute(ComponentTransfer transfer) throws TransferException{
        ComponentId compId = transfer.getComponentId();             // ID komponentu nowego transferu.
        DeviceId sourceId = transfer.getSourceDeviceId();           // ID urządzenia, z którego tranfer wychodzi.
        DeviceId destId = transfer.getDestinationDeviceId();        // ID urządzenia, na które transfer chce dotrzeć.
        if (compId == null || sourceId == null && destId == null){  // Sprawdza, czy transfer jest jednym z trzech dozwolonych.
            throw new IllegalTransferType(compId);
        }
        else if (sourceId != null && !deviceInfo.containsKey(sourceId)){  // Sprawdza, czy urządzenie macierzyste istnieje w systemie.
            throw new DeviceDoesNotExist(sourceId);
        }
        else if ((destId != null && !deviceInfo.containsKey(destId))){    // Sprawdza, czy urządzenie docelowe istnieje w systemie.
            throw new DeviceDoesNotExist(destId);
        }
        else if (!beingTransfered.add(compId)){                           // Sprawdza, czy komponent nie jest już tranferowany.
            throw new ComponentIsBeingOperatedOn(compId);
        }
        else {
            if (sourceId == null) {  // Transfer dodający komponent.
                // Sprawdza, czy dodawany komponent nie istnieje w systemie.
                if (compLoc.containsKey(compId)){
                    beingTransfered.remove(compId);  // Transfer przestaje być wykonywany.
                    throw new ComponentAlreadyExists(compId, compLoc.get(compId));
                }
                addNewComp(transfer);  // Dodawanie komponentu.
            } else {
                // Sprawdza, czy komponent jest na urządzeniu, z którego jest transferowany.
                if (!compLoc.containsKey(compId) || !compLoc.get(compId).equals(sourceId)){
                    beingTransfered.remove(compId);  // Transfer przestaje być wykonywany.
                    throw new ComponentDoesNotExist(compId, sourceId);
                }
                if (transfer.getDestinationDeviceId() == null) {  // Transfer usuwający komponent.
                    removeComp(transfer);  // Usuwanie komponentu.
                }
                else {                                            // Transfer przenoszący komponent.
                    // Sprawdza, czy komponent znajduje się na urządzeniu, na które ma zostać przeniesiony.
                    if (compLoc.containsKey(compId) && destId.equals(compLoc.get(compId))){
                        beingTransfered.remove(compId);  // Transfer przestaje być wykonywnym.
                        throw new ComponentDoesNotNeedTransfer(compId, sourceId);
                    }
                    changeLoc(transfer);  // Przenoszenie komponentu.
                }
            }
        }

    }

    // Przenosi komponent z urządzenia na drugie, w momencie, gdy będzie wolne miejsce.
    private void changeLoc(ComponentTransfer transfer){
        try {
            transferMutex.acquire();  // Jeden transfer naraz szuka miejsca w systemie.
        }catch (InterruptedException e){
            throw new RuntimeException("panic: unexpected thread interruption");
        }

        LinkedList<ComponentTransfer> cycle = new LinkedList<>();  // Grupa transferów, które można wykonać.
        cycle.add(transfer); // Dodajemy do cyklu pierwszy element.
        Device destDev = deviceInfo.get(transfer.getDestinationDeviceId());  // Urządzenie docelowe transferu.

        // Na urządzeniu docelowym jest miejsce na nowy komponent.
        if (destDev.getSizeLeft() > 0){
            try {
                prepMutex.acquire();
            }catch (InterruptedException e){
                throw new RuntimeException("panic: unexpected thread interruption");
            }
            Semaphore prepSem = new Semaphore(1);  // Jeśli miejsce transferu jest wolne, to wykona 'perform' od razu.
            if (destDev.checkPrep()){  // Sprawdza, czy jego miejsce jest jeszcze zajęte.
                prepSem = destDev.getPrep();  // Zwraca semaphore, na którym ma czekać z prepare.
            }
            destDev.addComponent();  // Rezerwuje miejsce dla nowego komponentu.
            prepMutex.release();

            Semaphore second = awakeChain(transfer.getSourceDeviceId());  // Budzi grupę najdłużej czekających transferów.
            Device sourceDev = deviceInfo.get(transfer.getSourceDeviceId());  // Macierzyste urządzenie pierwszego elementu.

            if (second == null){  // Jeśli transfer jest ostatnim z grupy.
                try {
                    prepMutex.acquire();

                }catch (InterruptedException e){
                    throw new RuntimeException("panic: unexpected thread interruption");
                }
                Semaphore preparing = new Semaphore(0);  // Semaphore na czas 'prepare'.
                sourceDev.addPrep(preparing);  // Dodaje semaphore, wstrzymujący 'perform' na jego miejsce.
                prepMutex.release();
                transferMutex.release();  // Nowy transfer może wejść do systemu.
                transfer.prepare();
                try {
                    prepMutex.acquire();
                }catch (InterruptedException e){
                    throw new RuntimeException("panic: unexpected thread interruption");
                }
                if (!sourceDev.checkAndRemove(preparing)){  // Po zakończeniu 'prepare' szuka swojego semaphore'a.
                    preparing.release();  // Jeśli nie znalazł semaphore'a, to znaczy, że ktoś czeka z 'perform' na jego miejsce.
                }
                prepMutex.release();
            }

            else{  // Transfer nie jest ostatnim elementem z grupy transferów (Ktoś z grupy rezerwuje jego miejsce).
                transferMutex.release();
                transfer.prepare();
                second.release();  // Kolejny transfer z grupy może robić 'perform' na miejsce transferu.
            }
            compLoc.replace(transfer.getComponentId(), transfer.getDestinationDeviceId());  // Zmienia lokalizację pierwszego komponentu w grupie.
            try {
                prepSem.acquire();  // Czeka na zakończenie 'prepare' transferu, którego miejsce ma się dostać.
            }catch (InterruptedException e){
                throw new RuntimeException("panic: unexpected thread interruption");
            }
            transfer.perform();
            beingTransfered.remove(transfer.getComponentId());  // Usuwa transfer z aktualnie wykonywanych.
        }

        // Odnajduje grupę transferów tworzącą cykl.
        else if (getCycle(cycle, transfer.getSourceDeviceId(), transfer.getDestinationDeviceId())) {
            Semaphore head = new Semaphore(0);  // Semaphore, który kontroluje, czy ostatni transfer z grupy zrobił 'prepare'.
            Semaphore sem = startCycle(cycle, head);  // Transfery z grupy przestają oczekiwać na miejsce.
            transferMutex.release();  // Nowy transfer może zacząć się wykonywać.
            transfer.prepare();
            sem.release();  // Transfer czekający na miejsce tego może zacząć wykonywać 'perform'.
            compLoc.replace(transfer.getComponentId(), transfer.getDestinationDeviceId());  // Zmienia lokalizację pierwszego komponentu w grupie.
            try {
                head.acquire();  // Czeka, aż poprzedni transfer z grupy wykona 'prepare'.
            }catch (InterruptedException e){
                throw new RuntimeException("panic: unexpected thread interruption");
            }
            transfer.perform();
            beingTransfered.remove(transfer.getComponentId());  // Usuwa transfer z aktualnie wykonywanych.
        }

        // Nie istnieje grupa transferów możliwych do wykonania.
        else {
            sleep(transfer);   // Transfer czeka, aż zostanie dodany do grupy transferów możliwych do wykonania.
            wakeUp(transfer);  // Transfer został dodany do grupy i zaczyna się wykonywać.
        }
    }

    // Usuwa komponent z systemu i znajduje inne na jego miejsce, jeśli takowe istnieją.
    private void removeComp(ComponentTransfer transfer){
        try {
            transferMutex.acquire();  // Jeden transfer naraz szuka miejsca w systemie.

        }catch (InterruptedException e){
            throw new RuntimeException("panic: unexpected thread interruption");
        }
        Semaphore second = awakeChain(transfer.getSourceDeviceId());  // Budzi grupy najdłużej czekających transferów.
        Device sourceDev = deviceInfo.get(transfer.getSourceDeviceId());  // Urządzenie macierzyste transferu.
        if (second == null){  // Jeśli jest jedynym w grupie transferów wykonywanych.
            try {
                prepMutex.acquire();  // Jeden transfer naraz szuka miejsca w systemie.
            }catch (InterruptedException e){
                throw new RuntimeException("panic: unexpected thread interruption");
            }
            Semaphore preparing = new Semaphore(0);  // Semaphore na czas wykonywania 'prepare'.
            sourceDev.addPrep(preparing);                   // Dodaje semaphore, do kolejki robiących 'prepare' na tym urządzeniu.
            prepMutex.release();
            transferMutex.release();
            transfer.prepare();
            try {
                prepMutex.acquire();
            }catch (InterruptedException e){
                throw new RuntimeException("panic: unexpected thread interruption");
            }
            if (!sourceDev.checkAndRemove(preparing)){  // Po zakończeniu 'prepare' szuka swojego semaphore'a.
                preparing.release();  // Jeśli nie znalazł semaphore'a, to znaczy, że ktoś czeka z 'perform' na jego miejsce.
            }
            prepMutex.release();
        }
        else{  // Nie jest jedynym w grupie się przenoszącej.
            transferMutex.release();
            transfer.prepare();
            second.release();  // Transfer przechodzący na jego miejsce może wykonywać 'perform'.
        }
        compLoc.remove(transfer.getComponentId());          // Usuwa komponent z systemu.
        transfer.perform();
        beingTransfered.remove(transfer.getComponentId());  // Usuwa transfer z aktualnie wykonywanych.
    }

    // Dodaje nowy komponent do systemu, jeśli jest miejsce na urządzeniu docelowym.
    private void addNewComp(ComponentTransfer transfer) {
        try {
            transferMutex.acquire();  // Jeden transfer naraz szuka miejsca w systemie.

        } catch (InterruptedException e) {
            throw new RuntimeException("panic: unexpected thread interruption");
        }
        Device destDev = deviceInfo.get(transfer.getDestinationDeviceId());  // Urządzenie docelowe.
        if (destDev.getSizeLeft() > 0) {  // Jest miejsce na urządzeniu docelowym.
            try {
                prepMutex.acquire();
            }catch (InterruptedException e){
                throw new RuntimeException("panic: unexpected thread interruption");
            }
            Semaphore prepSem = new Semaphore(1);  // Jeśli miejsce transferu jest wolne, to wykona 'perform' od razu.
            if (destDev.checkPrep()){  // Sprawdza, czy wszystkie wolne miejsca, są jeszcze zajmowane przez transfery wykonujące 'prepare'.
                prepSem = destDev.getPrep();  // Jeśli tak, to transfer będzie czekał z 'perform' na wykonanie 'prepare' poprzednika.
            }
            destDev.addComponent();           // Rezerwuje miejsce dla nowego komponentu.
            prepMutex.release();
            transferMutex.release();     // Nowy transfer może zacząć się wykonywać.
            transfer.prepare();
            compLoc.put(transfer.getComponentId(), destDev.getID());  // Dodaje nowy komponent do systemu.
            try {
                prepSem.acquire();  // Czeka, aż transfer z miejsca, w które ten się przenosi, wykonał 'prepare'.

            }catch (InterruptedException e){
                throw new RuntimeException("panic: unexpected thread interruption");
            }
            transfer.perform();
            beingTransfered.remove(transfer.getComponentId());       // Usuwa transfer z aktualnie się wykonujących.
        } else {
            sleep(transfer);           // Transfer czeka, aż zostanie dodany do grupy transferów możliwych do wykonania.
            wakeUp(transfer);          // Transfer został dodany do grupy i zaczyna się wykonywać.
        }
    }


    // Budzi grupę tranferów możliwych do wykonania, gdy główny tr1ansfer wykonywany jest na urządzenie z wolnym miejscem.
    private Semaphore awakeChain(DeviceId deviceId){
        boolean end = false;
        Device currentDev = deviceInfo.get(deviceId);  // Macierzyste urządzenie ostatnio dodanego do grupy transferu.
        LinkedList<ComponentTransfer> transfers = currentDev.getWaiting();  // Transfery czekające na miejsce na macierzystym urządzeniu.
        ComponentTransfer transfer = null;  // Transfer poprzedni w łańcuchu.
        Semaphore given = null;  // Semaphore drugiego transferu z grupy.
        if (transfers.size() > 0){  // Na miejsce pierwszego transferu czekają jakieś inne.
            transfer = transfers.getFirst();    // Drugi transfer z grupy.
            given = performs.get(transfer);   // Semaphore, na którym będzie czekał z wykonaniem 'perform', na 'prepare' poprzednika.
            currentDev.transferDev(transfer);   // Transfer przestaje czekać na miejsce.
            currentDev = deviceInfo.get(transfer.getSourceDeviceId());  // Jego macierzyste urządzenie.
        }
        else {  // Nikt nie czeka na miejsce pierwszego transferu.
            end = true;
            deviceInfo.get(deviceId).removeComponent();  // Jeśli nie było transferów na miejsce pierwszego, to zwalnia miejsce po nim.
        }
        while (!end){
            if (currentDev == null){              // Jeśli transfer jest dodawany.
                waiting.get(transfer).release();  // Transfer może wykonywać 'prepare'.
                end = true;
            }
            else if (currentDev.getWaiting().size() == 0){  // Jeśli nie ma transferów czekających na miejsce ostatniego transferu.
                currentDev.removeComponent();               // Zwalniamy miejsce na urządzeniu ostatniego transferu.
                tails.add(transfer);  // Dodaje transfer, jako koniec grupy.
                try {
                    prepMutex.acquire();
                }catch (InterruptedException e){
                    throw new RuntimeException("panic: unexpected thread interruption");
                }
                Semaphore preparing = new Semaphore(0);  // Semaphore stopujący inne transfery przed wykonaniem 'perform' na miejsce tego.
                currentDev.addPrep(preparing);  // Dodajemy semaphore do kolejki semaphorów należących do transferów wykonujących 'prepare'.
                prepMutex.release();
                currentDev.addSem(transfer, preparing);  // Po zakończeniu 'prepare' semaphore będzie zwalniał ten semaphore.
                waiting.get(transfer).release();         // Transfer może wykonywać 'prepare'.
                end = true;
            }
            else {  // Jeżeli na miejsce transferu czekają inne.
                transfers = currentDev.getWaiting();  // Transfery czekające na miejsce na tym urządzeniu.
                ComponentTransfer nextTransfer = transfers.getFirst();    // Transfer czekający najdłużej.
                currentDev.addSem(transfer, performs.get(nextTransfer));  // Przekazuje swój semaphore gotowści do 'perform' poprzedniemu.
                waiting.get(transfer).release();    // Poprzedni może wykonywać 'prepare'.
                transfer = nextTransfer;            // Transfer następny staje się nowym początkowym.
                currentDev.transferDev(transfer);   // Transfer przestaje czekać na miejsce.
                currentDev = deviceInfo.get(transfer.getSourceDeviceId());  // Urządzenie macierzyste początkowego transferu.
            }
        }
        return given;
    }

    // Szuka grupy transferów możliwych do wykonania, w której występuje cykl.
    private boolean getCycle(LinkedList<ComponentTransfer> chain, DeviceId deviceId, DeviceId headDestination){
        int index = 0;          // Index aktualnie oglądanego transferu.
        boolean found = false;  // Trzyma informację o tym, czy znaleziono cykl.
        Device currentDev = deviceInfo.get(deviceId);                         // Urządzenie macierzyste poprzedniego transferu.
        LinkedList<ComponentTransfer> currentList = currentDev.getWaiting();  // Transfery czekające na miejsce na tym urządzeniu.
        while (index < currentList.size() && !found)  // Póki nie znaleziono cyklu, a jeszcze są nierozpatrzone transfery.
        {
            ComponentTransfer transfer = currentList.get(index);  // Potencjalny transfer pasujący do cyklu.
            chain.add(transfer);                                  // Dodajemy do grupy.

            // Jeśli transfer jest dodawany do systemu, to nie pasuje do cyklu.
            if (transfer.getSourceDeviceId() == null){
                chain.removeLast();
            }
            // Jeśli urządzenie macierzyste transferu jest tym samym, na które chce dotrzeć pierwszy transfer.
            else if (headDestination.equals(transfer.getSourceDeviceId())){
                found = true;  // Znaleziono cykl.
            }
            // Jeśli urządzenie macierzyste transferu jest inne niż docelowe pierwszego.
            else{
                // Szuka cyklu z aktualny, transferem.
                if (getCycle(chain, transfer.getSourceDeviceId(), headDestination)){ // Szuka cyklu głębiej.
                    found = true;  // Znaleziono cykl.
                }
                // Brak cyklu z aktualnym transferem.
                else {
                    chain.removeLast();  // Nie znaleziono z tym transferem cyklu, więc zostaje usunięty.
                }
            }
            index++;
        }
        return found;
    }


    // Usuwa informacje o oczekiwaniu grupy możliwych do wykonania transferów.
    private Semaphore startCycle(LinkedList<ComponentTransfer> chain, Semaphore head) {
        ComponentTransfer transfer = chain.get(1);                           // Aktualnie rozpatrywany transfer
        Semaphore given = performs.get(transfer);                            // Zapamiętuje semaphore pierwszego z cyklu.
        for (int i = 1; i < chain.size() - 1; i++){
            transfer = chain.get(i);                                         // I-ty transfer z grupy.
            Device dev = deviceInfo.get(transfer.getSourceDeviceId());       // Urządzenie macierzyste tego transferu.
            deviceInfo.get(transfer.getDestinationDeviceId()).transferDev(transfer);  // Transfer przestaje czekać na miejsce.                                // Transfer przestaje czekać na miejsce.
            dev.addSem(transfer, performs.get(chain.get(i + 1)));            // Transfer dostaje semaphore następnika.
            waiting.get(transfer).release();                                 // Transfer może wykonywać 'prepare'.
        }
        transfer = chain.get(chain.size() - 1);                                   // Ostatni transfer z grupy.
        deviceInfo.get(transfer.getDestinationDeviceId()).transferDev(transfer);  // Transfer przestaje czekać na miejsce.
        Device dev = deviceInfo.get(transfer.getSourceDeviceId());                // Urządzenie docelowe tego transferu.
        dev.addSem(transfer, head);                                               // Transfer dostaje semaphore pierwszego elementu.
        waiting.get(transfer).release();                                          // Transfer może zacząć wykonywać 'prepare'.
        return given;  // Oddaje semaphore transferu czekającego z 'perform' na pierwszy.
    }

    // Czeka na dołączenie do grupy możliwych do wykonania transferów.
    public void sleep(ComponentTransfer transfer)
    {
        deviceInfo.get(transfer.getDestinationDeviceId()).waitDev(transfer);  // Transfer jest zapisywany jako czekający na miejsce na urządzeniu docelowym.
        performs.put(transfer, new Semaphore(0));  // Semaphore, na którym czeka z wykonaniem 'perform' na miejsce po poprzedniku.
        Semaphore sleep = new Semaphore(0);  // Semaphore, na którym czeka, aż znajdzie się w grupie transferów możliwych do wykonania.
        waiting.put(transfer, sleep);  // Zapisuje semaphore.
        transferMutex.release();  // Nowy transfer może zacząć się wykonywać.
        try {
            sleep.acquire();// Czeka na dołączenie do grupy możliwych do wykonania transferów.
        }catch (InterruptedException e){
            throw new RuntimeException("panic: unexpected thread interruption");
        }
        waiting.remove(transfer);  // Usuwa niepotrzebny już semaphore.

    }

    // Transfer został dołączony do grupy możliwych do wykonania.
    public void wakeUp(ComponentTransfer transfer)
    {
        transfer.prepare();
        if (transfer.getSourceDeviceId() != null){  // Jeśli transfer ma urządzenie macierzyste.
            Device sourceDev = deviceInfo.get(transfer.getSourceDeviceId());  // Urządzenie macierzyste transferu.
            Semaphore next = sourceDev.getSem(transfer);  // Semaphore następnika, czekającego na 'prepare' aktualnego.
            next.release();                // Zaznacza na semaphorze następnika, że wykonał 'prepare'.
            sourceDev.removeSem(transfer); // Usuwa niepotrzebny już semaphore.
            if (tails.remove(transfer)) {  // Jeśli transfer był ostatni w grupie.
                try {
                    prepMutex.acquire();
                } catch (InterruptedException e) {
                    throw new RuntimeException("panic: unexpected thread interruption");
                }
                sourceDev.checkAndRemove(next);  // Usuwa semaphore, jeśli nikt na nim nie czekał.
                prepMutex.release();
            }
            compLoc.replace(transfer.getComponentId(), transfer.getDestinationDeviceId());  // Zmienia lokalizację komponentu.
        }
        else {  // Jeśli transfer jest dodawany do systemu.
            compLoc.put(transfer.getComponentId(), transfer.getDestinationDeviceId());  // Zapisuje jego lokalizację.
        }
        try {
            performs.get(transfer).acquire();  // Czeka, aż poprzedni transfer z grupy możliwych do wykonania zrobi 'prepare'.
        }catch (InterruptedException e){
            throw new RuntimeException("panic: unexpected thread interruption");
        }
        transfer.perform();
        beingTransfered.remove(transfer.getComponentId());  // Transfer przestaje być wykonywany.
    }

    // Umieszcza nowe urządzenia.
    public void putDev(Device dev)
    {
        // Jeśli istnieje już urządzenie o takim ID w systemie.
        if (deviceInfo.containsKey(dev.getID())) {
            throw new IllegalArgumentException("Device " + dev.getID() + " is being created multiple times.");
        }
        deviceInfo.put(dev.getID(), dev);
    }

    // Umieszcza nowe komponenty na urządzeniach.
    public void putComp(ComponentId compId, DeviceId devId)
    {
        // Nie istnieje urządzenie o podanym ID.
        if (!deviceInfo.containsKey(devId)){
            throw new IllegalArgumentException("Device " + devId + " does not exist in the system so component " + compId + " cannot be added to it.");
        }
        else{
            Device device = deviceInfo.get(devId);  // Urządzenie, na którym komponent się ma znaleźć.
            // Jeśli urządzenie jest pełne.
            if (device.getSizeLeft() == 0)
            {
                throw new IllegalArgumentException("There are too many components assigned to device " + devId);
            }
            // Jeśli istnieje już komponent o takim numerze w systemie.
            else if (compLoc.containsKey(compId)){
                throw new IllegalArgumentException("Component " + compId + " is being assigned multiple times.");
            }
            device.addComponent();  // Zmniejsza wolne miejsce na urządzeniu.
            compLoc.put(compId, device.getID());  // Umieszcza komponent na urządzeniu.
        }
    }
    public System(){}
}
